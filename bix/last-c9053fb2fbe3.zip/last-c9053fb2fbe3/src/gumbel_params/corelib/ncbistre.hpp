#ifndef CORELIB___NCBISTRE__HPP
#define CORELIB___NCBISTRE__HPP

#  include <iostream>

#    define IO_PREFIX   NCBI_NS_STD

#define NcbiCout                 IO_PREFIX::cout

#endif /* NCBISTRE__HPP */
